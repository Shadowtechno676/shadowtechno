@echo off
cd /d "%~dp0"
echo Installation des dependances...
call npm install
if errorlevel 1 (echo Echec npm install & pause & exit /b 1)
echo Creation de l'installateur Windows...
call npm run dist:win
if errorlevel 1 (echo Echec de compilation & pause & exit /b 1)
echo Termine. Verifie le dossier release.
pause
