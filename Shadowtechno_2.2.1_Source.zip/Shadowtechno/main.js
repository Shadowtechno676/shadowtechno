const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const { Client: SSHClient } = require('ssh2');
const Database = require('better-sqlite3');
let db, activeUserId = null;
const TABLES = new Set(['channels','videos','projects','notes','events','time_entries','equipment','assets','comments','studio_scenes']);
function initDb(){
  const file=path.join(app.getPath('userData'),'shadowtechno.sqlite'); db=new Database(file); db.pragma('journal_mode = WAL');
  db.exec(`CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY, name TEXT NOT NULL, url TEXT DEFAULT '', subscribers TEXT DEFAULT '', views TEXT DEFAULT '', video_count TEXT DEFAULT '', thumbnail TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS videos(id INTEGER PRIMARY KEY, title TEXT NOT NULL, channel TEXT DEFAULT '', status TEXT DEFAULT 'Idée', due_date TEXT DEFAULT '', notes TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT NOT NULL, status TEXT DEFAULT 'En cours', description TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, title TEXT NOT NULL, content TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, title TEXT NOT NULL, event_date TEXT DEFAULT '', details TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS time_entries(id INTEGER PRIMARY KEY, label TEXT NOT NULL, minutes INTEGER DEFAULT 0, entry_date TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS equipment(id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT DEFAULT '', details TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS assets(id INTEGER PRIMARY KEY, name TEXT NOT NULL, kind TEXT DEFAULT 'Fichier', url TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY, target TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS studio_scenes(id INTEGER PRIMARY KEY, name TEXT NOT NULL, scene_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS sync_queue(id INTEGER PRIMARY KEY, owner_id TEXT NOT NULL, table_name TEXT NOT NULL, record_id INTEGER NOT NULL, operation TEXT NOT NULL, payload TEXT DEFAULT '{}', created_at TEXT DEFAULT CURRENT_TIMESTAMP, synced INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS settings(owner_id TEXT NOT NULL DEFAULT 'global', key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(owner_id,key));`);
  const oldSettingsCols=db.prepare('PRAGMA table_info(settings)').all().map(x=>x.name);
  if(!oldSettingsCols.includes('owner_id')){ db.exec('ALTER TABLE settings RENAME TO settings_legacy'); db.exec('CREATE TABLE settings(owner_id TEXT NOT NULL DEFAULT \"global\", key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(owner_id,key))'); }
  for(const table of TABLES){ const cols=db.prepare(`PRAGMA table_info(${table})`).all().map(x=>x.name); if(!cols.includes('owner_id')) db.exec(`ALTER TABLE ${table} ADD COLUMN owner_id TEXT`); }
  const channelCols=db.prepare('PRAGMA table_info(channels)').all().map(x=>x.name); for(const [col,decl] of [['subscribers',"TEXT DEFAULT ''"],['views',"TEXT DEFAULT ''"],['video_count',"TEXT DEFAULT ''"],['thumbnail',"TEXT DEFAULT ''"],['youtube_id',"TEXT DEFAULT ''"],['latest_video',"TEXT DEFAULT ''"],['latest_video_url',"TEXT DEFAULT ''"]]) if(!channelCols.includes(col)) db.exec(`ALTER TABLE channels ADD COLUMN ${col} ${decl}`);
  const qcols=db.prepare('PRAGMA table_info(sync_queue)').all().map(x=>x.name); if(!qcols.includes('owner_id')) db.exec("ALTER TABLE sync_queue ADD COLUMN owner_id TEXT");
}
function requireUser(){if(!activeUserId) throw new Error('Connecte-toi à ton compte Shadowtechno.'); return activeUserId;}
function createWindow(){const win=new BrowserWindow({width:1500,height:950,minWidth:1050,minHeight:700,backgroundColor:'#0b0d14',title:'Shadowtechno',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true,webviewTag:true}});win.loadFile('index.html');}
ipcMain.handle('auth:set-user',(_,id)=>{if(typeof id!=='string'||!id.trim())throw Error('Identifiant de compte invalide');activeUserId=id;return true;});
ipcMain.handle('auth:clear-user',()=>{activeUserId=null;return true;});
ipcMain.handle('db:list',(_,table)=>{const owner=requireUser();if(!TABLES.has(table))throw Error('Table non autorisée');return db.prepare(`SELECT * FROM ${table} WHERE owner_id=? ORDER BY id DESC`).all(owner);});
ipcMain.handle('db:add',(_,table,data)=>{const owner=requireUser();if(!TABLES.has(table))throw Error('Table non autorisée');const cols=Object.keys(data||{}).filter(k=>/^[a-z_]+$/.test(k)&&k!=='owner_id'&&k!=='id');if(!cols.length)throw Error('Aucune donnée');const stmt=db.prepare(`INSERT INTO ${table} (${[...cols,'owner_id'].join(',')}) VALUES (${[...cols.map(x=>`@${x}`),'@owner_id'].join(',')})`);const info=stmt.run({...data,owner_id:owner});db.prepare('INSERT INTO sync_queue(owner_id,table_name,record_id,operation,payload) VALUES(?,?,?,?,?)').run(owner,table,info.lastInsertRowid,'upsert',JSON.stringify(data));return {id:info.lastInsertRowid};});
ipcMain.handle('db:remove',(_,table,id)=>{const owner=requireUser();if(!TABLES.has(table))throw Error('Table non autorisée');db.prepare(`DELETE FROM ${table} WHERE id=? AND owner_id=?`).run(Number(id),owner);db.prepare('INSERT INTO sync_queue(owner_id,table_name,record_id,operation,payload) VALUES(?,?,?,?,?)').run(owner,table,Number(id),'delete','{}');return true;});
ipcMain.handle('db:stats',()=>{const owner=requireUser();return {videos:db.prepare('SELECT count(*) n FROM videos WHERE owner_id=?').get(owner).n,projects:db.prepare('SELECT count(*) n FROM projects WHERE owner_id=?').get(owner).n,ideas:0,queue:db.prepare('SELECT count(*) n FROM sync_queue WHERE owner_id=? AND synced=0').get(owner).n};});
ipcMain.handle('settings:get',(_,key)=>{const owner=['supabaseUrl','supabaseKey'].includes(key)?'global':(activeUserId||'global');return db.prepare('SELECT value FROM settings WHERE owner_id=? AND key=?').get(owner,key)?.value||'';});
ipcMain.handle('settings:set',(_,key,value)=>{const owner=['supabaseUrl','supabaseKey'].includes(key)?'global':(activeUserId||'global');db.prepare('INSERT INTO settings(owner_id,key,value) VALUES(?,?,?) ON CONFLICT(owner_id,key) DO UPDATE SET value=excluded.value').run(owner,String(key),String(value));return true;});

ipcMain.handle('server:run',async(_,server,action)=>{
  requireUser();
  if(!server||typeof server!=='object')throw Error('Configuration du serveur invalide.');
  const {host,username,keyPath}=server;
  if(typeof host!=='string'||!/^[a-zA-Z0-9.:-]{1,253}$/.test(host))throw Error('Adresse IP ou nom Tailscale invalide.');
  if(typeof username!=='string'||!/^[a-z_][a-z0-9_-]{0,31}$/i.test(username))throw Error('Nom d’utilisateur SSH invalide.');
  if(typeof keyPath!=='string'||!path.isAbsolute(keyPath)||keyPath.includes('\0'))throw Error('Chemin de clé SSH invalide.');
  const commands={status:'printf "\n--- UPTIME ---\n"; uptime; printf "\n--- MEMOIRE ---\n"; free -h; printf "\n--- DISQUE ---\n"; df -h /; printf "\n--- TEMPERATURE ---\n"; (sensors 2>/dev/null | head -12 || true)',docker:'docker ps --format "table {{.Names}}\\t{{.Status}}\\t{{.Ports}}"'};
  if(!Object.prototype.hasOwnProperty.call(commands,action))throw Error('Commande serveur non autorisée.');
  const privateKey=fs.readFileSync(keyPath);
  return await new Promise((resolve,reject)=>{
    const conn=new SSHClient();let done=false,timer;const finish=(err,val)=>{if(done)return;done=true;if(timer)clearTimeout(timer);conn.end();err?reject(err):resolve(val);};
    conn.on('ready',()=>conn.exec(commands[action],{pty:false},(err,stream)=>{if(err)return finish(err);let output='',stderr='';stream.on('data',d=>output+=d.toString());stream.stderr.on('data',d=>stderr+=d.toString());stream.on('close',code=>finish(code===0?null:Error(stderr||`Commande terminée avec le code ${code}`),output.trim()||'Aucune sortie.'));}));
    conn.on('error',e=>finish(Error(e.message||'Connexion SSH impossible.')));
    conn.connect({host,port:22,username,privateKey,readyTimeout:12000,keepaliveInterval:5000});
    timer=setTimeout(()=>finish(Error('Délai SSH dépassé (12 secondes).')),15000);
  });
});

ipcMain.handle('oauth:google',async(_,clientId)=>{if(typeof clientId!=='string'||!clientId.endsWith('.apps.googleusercontent.com'))throw Error('Utilise un Client ID OAuth de type application de bureau Google.');const port=53682,redirect=`http://127.0.0.1:${port}/`,verifier=crypto.randomBytes(32).toString('base64url'),challenge=crypto.createHash('sha256').update(verifier).digest('base64url'),state=crypto.randomBytes(18).toString('hex');const authUrl=new URL('https://accounts.google.com/o/oauth2/v2/auth');Object.entries({client_id:clientId,redirect_uri:redirect,response_type:'code',scope:'https://www.googleapis.com/auth/youtube.readonly',code_challenge:challenge,code_challenge_method:'S256',state,access_type:'offline',prompt:'consent'}).forEach(([k,v])=>authUrl.searchParams.set(k,v));return await new Promise((resolve,reject)=>{let finished=false;const finish=(err,val)=>{if(finished)return;finished=true;clearTimeout(timer);server.close();err?reject(err):resolve(val);};const server=http.createServer(async(req,res)=>{const u=new URL(req.url,redirect);if(u.searchParams.get('state')!==state){res.writeHead(400);res.end('Etat OAuth invalide. Tu peux fermer cette fenêtre.');return finish(Error('État OAuth invalide.'));}const code=u.searchParams.get('code');if(!code){res.writeHead(400);res.end('Autorisation refusée.');return finish(Error('Autorisation Google refusée.'));}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end('<h2>Shadowtechno connecté à Google</h2><p>Tu peux fermer cette fenêtre et revenir dans l’application.</p>');try{const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:clientId,code,code_verifier:verifier,grant_type:'authorization_code',redirect_uri:redirect})});const data=await response.json();if(!response.ok)throw Error(data.error_description||data.error||'Échange OAuth impossible.');finish(null,data.access_token);}catch(e){finish(e);}});server.on('error',e=>finish(e));server.listen(port,'127.0.0.1',async()=>{try{await shell.openExternal(authUrl.toString());}catch(e){finish(e);}});const timer=setTimeout(()=>finish(Error('Délai de connexion Google dépassé.')),180000);});});
ipcMain.handle('external:open',(_,url)=>{const u=new URL(url);if(!['https:'].includes(u.protocol))throw Error('Lien non autorisé');return shell.openExternal(u.toString());});
ipcMain.handle('local:open-path',async(_,target)=>{if(process.platform!=='win32')throw Error('Les raccourcis de fichiers sont pris en charge sur Windows dans cette version.');if(typeof target!=='string'||!path.isAbsolute(target)||target.includes('\0'))throw Error('Chemin Windows absolu invalide.');const result=await shell.openPath(path.normalize(target));if(result)throw Error(result);return true;});
app.whenReady().then(()=>{initDb();createWindow();app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
