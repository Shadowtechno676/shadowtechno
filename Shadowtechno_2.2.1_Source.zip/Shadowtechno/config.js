// Configuration publique de l'application Shadowtechno.
// L'administrateur remplit ces deux valeurs UNE SEULE FOIS avant de distribuer l'application.
// La clé anon/publishable est destinée au client. NE JAMAIS mettre la clé service_role ici.
window.SHADOWTECHNO_CONFIG = {
  supabaseUrl: 'https://rfmrwcvjuuwwaylsgblr.supabase.co',
  supabaseAnonKey: 'sb_publishable_wjniwME7MKufZOEzRYhfKw_-1ucZL9y'
};
