import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } })

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  if (req.method !== 'POST') return json({ error: 'Méthode non autorisée.' }, 405)
  try {
    const url = Deno.env.get('SUPABASE_URL')!
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const authHeader = req.headers.get('Authorization') || ''
    const token = authHeader.replace(/^Bearer\s+/i, '')
    if (!token) return json({ error: 'Session manquante.' }, 401)
    const admin = createClient(url, serviceKey, { auth: { persistSession: false } })
    const { data: { user }, error: authError } = await admin.auth.getUser(token)
    if (authError || !user || user.email?.toLowerCase() !== 'shadowadmin@gmail.com') return json({ error: 'Accès administrateur refusé.' }, 403)
    const body = await req.json()
    if (body.action === 'list') {
      const { data, error } = await admin.auth.admin.listUsers({ page: 1, perPage: 200 })
      if (error) throw error
      return json({ users: data.users.map(u => ({ id: u.id, email: u.email, role: u.app_metadata?.role || 'user', username: u.user_metadata?.username || '' })) })
    }
    if (body.action === 'create') {
      const username = String(body.username || '').trim().toLowerCase()
      const password = String(body.password || '')
      const role = body.role === 'admin' ? 'admin' : 'user'
      if (!/^[a-z0-9._-]{3,24}$/.test(username)) return json({ error: 'Identifiant invalide (3 à 24 caractères).' }, 400)
      if (password.length < 8) return json({ error: 'Le mot de passe doit contenir au moins 8 caractères.' }, 400)
      const email = `${username}@accounts.shadowtechno.app`
      const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { username }, app_metadata: { role } })
      if (error) throw error
      return json({ user: { id: data.user.id, email: data.user.email, role } })
    }
    if (body.action === 'delete') {
      const userId = String(body.userId || '')
      const { data: target, error: findError } = await admin.auth.admin.getUserById(userId)
      if (findError) throw findError
      if (target.user.email?.toLowerCase() === 'shadowadmin@gmail.com') return json({ error: 'Le compte administrateur principal est protégé.' }, 400)
      const { error } = await admin.auth.admin.deleteUser(userId)
      if (error) throw error
      return json({ success: true })
    }
    if (body.action === 'role') {
      const userId = String(body.userId || '')
      const role = body.role === 'admin' ? 'admin' : 'user'
      const { data: target, error: findError } = await admin.auth.admin.getUserById(userId)
      if (findError) throw findError
      if (target.user.email?.toLowerCase() === 'shadowadmin@gmail.com' && role !== 'admin') return json({ error: 'Le rôle du compte principal ne peut pas être retiré.' }, 400)
      const { error } = await admin.auth.admin.updateUserById(userId, { app_metadata: { ...target.user.app_metadata, role } })
      if (error) throw error
      return json({ success: true })
    }
    return json({ error: 'Action inconnue.' }, 400)
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'Erreur serveur.' }, 400)
  }
})
